# Iris Flower Data Analysis Project

## Week 1 – Data Exploration and Problem Definition

This project performs exploratory data analysis (EDA) on the public Iris dataset.

### Objective
- Understand the dataset structure and data types
- Check data quality and missing values
- Calculate descriptive statistics
- Compare measurements across flower species
- Study relationships between numerical variables
- Create basic visualizations
- Define questions for further statistical analysis

### Dataset
The project uses the classic Iris dataset available through `scikit-learn`.
It contains 150 observations from three species: setosa, versicolor, and virginica.

### Technologies
Python, Pandas, NumPy, Matplotlib, Scikit-learn

### Project Structure
```text
iris-data-analysis-project/
├── analysis.py
├── requirements.txt
├── README.md
├── PROJECT_SUMMARY.md
├── .gitignore
└── outputs/
    ├── species_distribution.png
    ├── measurement_distributions.png
    ├── petal_relationship.png
    └── correlation_heatmap.png
```

### How to Run
```bash
pip install -r requirements.txt
python analysis.py
```

Charts will be generated inside `outputs/`.

### Key Questions
1. Which measurements differ most between species?
2. Are petal length and petal width strongly related?
3. Which variables visually separate the species?
4. Which measurements may be useful for future classification?

### Internship Deliverable
This repository supports the Week 1 internship task: Data Exploration and Problem Definition.

Educational project created for internship submission and portfolio demonstration.
