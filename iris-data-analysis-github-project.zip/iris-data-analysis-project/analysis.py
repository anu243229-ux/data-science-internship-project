import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load the public Iris dataset
iris = load_iris(as_frame=True)
df = iris.frame.copy()
df.columns = [
    "sepal_length_cm", "sepal_width_cm",
    "petal_length_cm", "petal_width_cm", "species_id"
]
df["species"] = df["species_id"].map(dict(enumerate(iris.target_names)))
df.drop(columns=["species_id"], inplace=True)

print("=" * 60)
print("IRIS FLOWER DATA ANALYSIS")
print("=" * 60)
print("\nDataset shape:", df.shape)
print("\nFirst five rows:\n", df.head())
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isnull().sum())
print("\nDescriptive statistics:\n", df.describe().round(2))
print("\nSpecies distribution:\n", df["species"].value_counts())
print("\nMean measurements by species:\n",
      df.groupby("species").mean(numeric_only=True).round(2))
print("\nCorrelation matrix:\n", df.iloc[:, :4].corr().round(2))

# 1. Species distribution
counts = df["species"].value_counts().reindex(iris.target_names)
plt.figure(figsize=(7, 5))
plt.bar(counts.index, counts.values)
plt.title("Iris Species Distribution")
plt.xlabel("Species")
plt.ylabel("Number of Samples")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/species_distribution.png", dpi=200)
plt.close()

# 2. Measurement distributions
features = list(df.columns[:4])
fig, axes = plt.subplots(2, 2, figsize=(10, 8))
for ax, feature in zip(axes.ravel(), features):
    groups = [df.loc[df["species"] == species, feature].values
              for species in iris.target_names]
    ax.boxplot(groups, tick_labels=iris.target_names)
    ax.set_title(feature.replace("_", " ").title())
    ax.set_ylabel("Centimetres")
plt.suptitle("Measurement Distributions by Species", fontsize=14)
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/measurement_distributions.png", dpi=200)
plt.close()

# 3. Petal relationship
plt.figure(figsize=(8, 6))
for species in iris.target_names:
    subset = df[df["species"] == species]
    plt.scatter(subset["petal_length_cm"], subset["petal_width_cm"],
                label=species)
plt.title("Petal Length vs Petal Width")
plt.xlabel("Petal Length (cm)")
plt.ylabel("Petal Width (cm)")
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/petal_relationship.png", dpi=200)
plt.close()

# 4. Correlation heatmap using only Matplotlib
corr = df.iloc[:, :4].corr().values
plt.figure(figsize=(7, 5))
plt.imshow(corr)
plt.colorbar(label="Correlation")
plt.xticks(range(4), ["Sepal L", "Sepal W", "Petal L", "Petal W"])
plt.yticks(range(4), ["Sepal L", "Sepal W", "Petal L", "Petal W"])
plt.title("Correlation Between Numerical Features")
for i in range(4):
    for j in range(4):
        plt.text(j, i, f"{corr[i, j]:.2f}", ha="center", va="center")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/correlation_heatmap.png", dpi=200)
plt.close()

print("\nAnalysis completed successfully.")
print("Charts saved in:", OUTPUT_DIR)
