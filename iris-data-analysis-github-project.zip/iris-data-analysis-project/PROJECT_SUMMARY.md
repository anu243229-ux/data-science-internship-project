# Project Summary

**Project:** Iris Flower Data Analysis

**Goal:** Explore a public dataset, understand variables, compare species, identify relationships, and define future analytics questions.

**Initial finding:** The exploratory summaries show clear differences between species, particularly in petal measurements. Petal length and petal width also show a strong positive relationship in the dataset.

**Next step:** Perform formal statistical tests such as ANOVA after checking assumptions, then build and validate a simple classification model.
